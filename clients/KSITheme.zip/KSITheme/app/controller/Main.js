Ext.define('MyApp.controller.Main', {
    extend: 'Ext.app.Controller'
});
